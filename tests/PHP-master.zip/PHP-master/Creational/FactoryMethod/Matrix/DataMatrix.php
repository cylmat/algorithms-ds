<?php

namespace Phpatterns\Creational\FactoryMethod\Matrix;

use Phpatterns\Creational\FactoryMethod;

class DataMatrix extends FactoryMethod\InformationMatrix
{
    public function __construct()
    {
        parent::__construct();
    }
}
